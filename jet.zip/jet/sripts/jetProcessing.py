ro = 1.2
p = 979
steps=800
length=44
ls=length/steps*10

def finder(location):
    f = open(location)
    pxx = []
    for i in range(0, 109):
        p0 = f.readline()
        if p0 == "":
            break
        pxx.append(int(p0))
    vxx = []
    for i in range(0, 109):
        v0 = (0.119 * abs(p - pxx[i]) * 2 / ro) ** 0.5
        vxx.append(v0)
    f.close()
    return vxx


v00 = finder("00 mm.txt")
v10 = finder("10 mm.txt")
v20 = finder("20 mm.txt")
v30 = finder("30 mm.txt")
v40 = finder("40 mm.txt")
v50 = finder("50 mm.txt")
v60 = finder("60 mm.txt")
v70 = finder("70 mm.txt")
v80 = finder("80 mm.txt")
v90 = finder("90 mm.txt")

def findmax(a):
    max = a[0]
    maxi = 0
    for i in range(0,len(a)):
        if a[i] > max:
            max = a[i]
            maxi = i
    return maxi           # - индекс максимального элемента массива

def centering(a):         # - сдвиг графика путем добавления нулей или удаления элементов в начале или конце
    shift = -findmax(a)
    r=[]
    for i in range(shift, 109+shift):
        r.append(i)
    return r

import numpy as np
r00=np.array(centering(v00))*ls
r10=np.array(centering(v10))*ls
r20=np.array(centering(v20))*ls
r30=np.array(centering(v30))*ls
r40=np.array(centering(v40))*ls
r50=np.array(centering(v50))*ls
r60=np.array(centering(v60))*ls
r70=np.array(centering(v70))*ls
r80=np.array(centering(v80))*ls
r90=np.array(centering(v90))*ls

from matplotlib import pyplot as plt
import matplotlib.ticker as tic

fig, ax = plt.subplots()
ax.plot(r00, v00, marker=".", label = "Q (00 мм) = 1.414 г/с")
ax.plot(r10, v10, marker=".", label = "Q (10 мм) = 1.407 г/с")
ax.plot(r20, v20, marker=".", label = "Q (20 мм) = 1.403 г/с")
ax.plot(r30, v30, marker=".", label = "Q (30 мм) = 1.407 г/с")
ax.plot(r40, v40, marker=".", label = "Q (40 мм) = 1.384 г/с")
ax.plot(r50, v50, marker=".", label = "Q (50 мм) = 1.395 г/с")
ax.plot(r60, v60, marker=".", label = "Q (60 мм) = 1.421 г/с")
ax.plot(r70, v70, marker=".", label = "Q (70 мм) = 1.427 г/с")
ax.plot(r80, v80, marker=".", label = "Q (80 мм) = 1.427 г/с")
ax.plot(r90, v90, marker=".", label = "Q (90 мм) = 1.463 г/с")
ax.set_xlim([-40, 40])
ax.set_ylim([-0.5, 25])
ax.yaxis.set_minor_locator(tic.MultipleLocator(0.2)) #делаем сетку
ax.xaxis.set_minor_locator(tic.MultipleLocator(1))
ax.yaxis.set_major_locator(tic.MultipleLocator(1))
ax.xaxis.set_major_locator(tic.MultipleLocator(5))
ax.grid(axis= 'both', which = 'minor', linestyle='--', linewidth=0.5, alpha=0.4, color='lightgrey', zorder=0)
ax.grid(axis= 'both', which = 'major', linestyle='-', linewidth=1, alpha=0.4, color='lightgrey', zorder=0)
ax.set_title("График зависимости скорости потока от расстояния до трубки Пито")
ax.set_ylabel('Скорость, м/с')
ax.set_xlabel('Расстояние, мм')
ax.legend(loc=0)
plt.show()
fig.savefig('velocity.png')

r = []
for i in range(0, 109):
    r0 = i
    r.append(i)

def q(a):
    qxx = 0
    for i in range(0, 108):
        qxx += 3.14159 * ro * (0.01*0.0055)**2*(abs(r[i] * a[i] + r[i + 1] * a[i + 1])) * 1000
    return qxx

from matplotlib import pyplot as plt

qall = [q(v00), q(v10), q(v20), q(v30), q(v40), q(v50), q(v60), q(v70), q(v80), q(v90)]
print(qall)

plt.plot([i * 10 for i in range(10)], qall, marker=".", label="Расход от расстояния")
plt.minorticks_on()
plt.grid(b=True, which="minor")
plt.grid(b=True)
plt.title("График зависимости расхода от расстояния до трубки Пито")
plt.ylabel('Расход')
plt.xlabel('Расстояние, мм')
plt.legend()
#plt.show() # - раскомментить, чтобы получить график
